// ==UserScript==
// @name         全网VIP视频免费破解去广告，一键领取淘宝、天猫、京东、唯品会、拼多多、抖音隐藏优惠券！全网查券！【免费领取京东、淘宝、唯品会618超级红包、外卖红包、公交地铁红包】
// @namespace    http://lctnq.yhzu.cn
// @version      1.2.9
// @description  1、一键破解[优酷|腾讯|乐视|爱奇艺|芒果|音悦台]等VIP视频；2、查询商家设置的隐藏优惠券，省钱开心购物，直接领取优惠券购买；3、接口不好用了请反馈给我记录更新（QQ群：668600818）。
// @author       赤练丶风
// @match        *://s.taobao.com/*
// @match        *://ai.taobao.com/search/*
// @match        *://list.tmall.com/*
// @match        *://item.taobao.com/*
// @match        *://detail.tmall.com/*
// @match        *://detail.tmall.hk/*
// @match        *://chaoshi.detail.tmall.com/*
// @match        *://detail.liangxinyao.com/*
// @match        *://*.jd.com/*
// @match        *://*.jd.hk/*
// @match        *://*.yiyaojd.com/*
// @match        *://*.jd.com/*
// @match        *://*.vip.com/*
// @match        *://*.vipglobal.hk/*
// @exclude      *://login.taobao.com/*
// @exclude      *://login.tmall.com/*
// @exclude      *://uland.taobao.com/*
// @exclude      *://pages.tmall.com/*
// @exclude      *://wq.jd.com/*
// @match   	 *://*.iqiyi.com/*
// @match   	 *://*.youku.com/*
// @match   	 *://v.qq.com/*
// @match   	 *://*.tudou.com/*
// @match   	 *://film.sohu.com/*
// @match   	 *://*.mgtv.com/*
// @match   	 *://*.acfun.cn/v/*
// @match  	  	 *://*.56.com/*
// @match   	 *://*.pptv.com/*
// @match   	 *://*.le.com/*
// @match   	 *://*.letv.com/*
// @match   	 *://tv.sohu.com/*
// @match   	 *://vip.1905.com/play/*
// @match   	 *://v.yinyuetai.com/video/*
// @match   	 *://v.yinyuetai.com/playlist/*
// @match  	 	 *://*.fun.tv/vplay/*
// @match  		 *://*.wasu.cn/Play/show/*
// @require      https://cdn.bootcss.com/jquery/2.2.4/jquery.min.js
// @antifeature  referral-link 【应GreasyFork代码规范要求：含有优惠券查询功能的脚本必须添加此提示！脚本使用过程中无任何强制跳转等行为，代码可查，请大家放心！在此感谢大家的理解...】
// @grant        GM_openInTab
// @grant        GM_registerMenuCommand
// @license      AGPL
// ==/UserScript==
(function() {
    GM_registerMenuCommand("首选全网查券地址",
                           function() {
        window.open("https://kzurl06.cn/uqSS3", "_blank");
    });
    GM_registerMenuCommand("备用淘宝查券地址",
                           function() {
        window.open("http://lctnq.yhzu.cn", "_blank");
    });
    GM_registerMenuCommand("最新活动地址（首选失效地址更新页）",
                           function() {
        window.open("https://shimo.im/docs/QV98k9PHRGkk6kvG/", "_blank");
    });
})();
(function () {
    'use strict';
    $(document).ready(function () {
        var host = window.location.host;
        var pid = '';
        var pname = '';
        var cssSelector = '';
        var coupon = '';
        var search = '';
        var TBCoupon = "https://renyigo8.kuaizhan.com/?cid=vKNsecgc#/detail?super=1&itemid=";
        var JDCoupon = "https://renyigo8.kuaizhan.com/?cid=vKNsecgc#/detail?platform=2&super=1&id="
        var VipCoupon = "https://renyigo8.kuaizhan.com/?cid=vKNsecgc#/detail?platform=5&itemid="
        var TBSearch = "https://renyigo8.kuaizhan.com/?cid=vKNsecgc#/search?keyword=";
        var JDSearch = "https://renyigo8.kuaizhan.com/?cid=vKNsecgc#/search?pt=2&keyword="
        var VipSearch = "https://renyigo8.kuaizhan.com/?cid=vKNsecgc#/search?pt=5&keyword="
        var RedPacket = "https://shimo.im/docs/QV98k9PHRGkk6kvG/";
        var VipRP = "https://qr21.cn/EtVOQ2";
        var Clabel = "领取商品优惠券";
        var Rlabel = "找券机器人|最新活动";
        var Viplabel = "领取优惠券";
        var AllSearch = "全网搜索";
        var DPacket = "https://m.tb.cn/h.ftSTGIn";
        var EPacket = "https://u.jd.com/JI7b2ZK";
        var Dlabel = "618淘宝超级红包";
        var Elabel = "618京东超级红包";
        pid = location.href;
        coupon = TBCoupon;
        search = TBSearch;
        if (host.indexOf('taobao.com') > 0) {
            pid = pid.split("id=")[1];
            pid = pid.split("&")[0];
            pname = $.trim($('.tb-main-title').text());
            cssSelector = '.tb-action';
        } else if (host == 'chaoshi.detail.tmall.com') {
            pid = pid.split("id=")[1];
            pid = pid.split("&")[0];
            pname = $.trim($('.tb-detail-hd h1').text());
            cssSelector = '.tb-action';
        } else if (host.indexOf('tmall.com') > 0 || host == 'detail.liangxinyao.com') {
            pid = pid.split("id=")[1];
            pid = pid.split("&")[0];
            pname = $.trim($('.tb-detail-hd h1').text());
            cssSelector = '.tb-action';
        } else if (host.indexOf('jd.com') > 0) {
            coupon = JDCoupon;
            search = JDSearch;
            pid = window.location.pathname;
            pid = pid.split("/")[1];
            pid = pid.split(".html")[0];
            pname = $.trim($('.sku-name').text());
            cssSelector = '#choose-btns';
        } else if (host.indexOf('vip.com') > 0) {
            function addGlobalStyle(css) {
                var head, style;
                head = document.getElementsByTagName('head')[0];
                if (!head) { return; }
                style = document.createElement('style');
                style.type = 'text/css';
                style.innerHTML = css;
                head.appendChild(style);
            }
            addGlobalStyle(`
.comparePricess {
    display: block;
    margin-top: 6px;
    font-size: 16px;
    color: #fff;
    text-align: center;
}`);
            coupon = VipCoupon;
            search = VipSearch;
            Clabel = Viplabel;
            pid = window.location.pathname;
            pid = pid.split("-")[2];
            pid = pid.split(".html")[0];
            cssSelector = 'div#J_detail_buy';
            setTimeout(() => {
                pname = document.getElementsByTagName('title')[0].innerHTML;
                Rlabel = VipRP;
                $(cssSelector).after(obtainAppendHtml(host, coupon,pid,search, pname, Clabel, RedPacket, Rlabel, AllSearch));
            },
                       2000);
        }else {
            const YoukuIcon = '<svg width="1.2em" height="1.2em" viewbox="0 0 72 72"><defs><circle id="youkuC1" r="5.5" style="stroke:none;;fill:#0B9BFF;"></circle><path id="youkuArow" d="m0,10 a5,5 0,0,1 0,-10 h20 a5,5 0,0,1 0,10z" style="fill:#FF4242;"></path></defs><circle cx="36" cy="36" r="30.5" style="stroke:#30B4FF;stroke-width:11;fill:none;"></circle><use x="10.5" y="19" xlink:href="#youkuC1"/><use x="61.5" y="53" xlink:href="#youkuC1"/><use x="39" y="1" transform="rotate(30)" xlink:href="#youkuArow"/><use x="-1" y="52" transform="rotate(-35)" xlink:href="#youkuArow"/></svg>';
            const VQQIcon = '<svg height="1.2em" width="1.2em" viewbox="0 0 185 170"><defs><path id="vQQ" d="M7 20Q14 -10 55 7Q100 23 145 60Q170 80 145 102Q108 138 47 165Q15 175 4 146Q-5 80 7 20"></path></defs><use style="fill:#44B9FD;" transform="translate(27,0)" xlink:href="#vQQ"></use><use style="fill:#FF9F01;" transform="translate(0,18),scale(0.8,0.75)" xlink:href="#vQQ"></use><use style="fill:#97E61B;" transform="translate(23,18),scale(0.80.75)" xlink:href="#vQQ"></use><use style="fill:#fff;" transform="translate(50,45),scale(0.4)" xlink:href="#vQQ"></use></svg>';
            const IQiyiIcon = '<svg xmlns="http://www.w3.org/2000/svg" x="0" y="0" width="12" height="12"><image width="12" height="12" x="0" y="0" href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAwAAAAMEAYAAAAG5YCkAAAABGdBTUEAALGPC/xhBQAAACBjSFJN AAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAABmJLR0T///////8JWPfcAAAA B3RJTUUH4wgJFC0QN86G4AAAA8FJREFUOMsFwX1MlHUAwPHv73meu5PjnWMSkSZYDHRuzj8UEbXN CudEQXQunAOzWnO1+V5BC5i6U7NcqPmW4cK0mSaWIYWJQbrKNSCiVGwnKHpyceDD2z33PPf8+nyE c/judTh3jQamQ2GZ7KALVJ/soxtA5tEDwBkeA6ARBqCIWABxjWcBRCI5AGI2z0NkKkX4of6kcMZ3 u8FUtZep13Zplme9OsPjh8Sl6s7EnyC6Rfkz5mlwbRVB5+dANhGRAeF+OdlogZG37byRKTDksvcN HYSBYqtt4DqEe8gyf7Y0kZx150psh5Tlucn5H3wI6XOV/Rn7QLetXL0XzDq5x/wM7DRZZieCXMYd uQTUcXFTBVwlSvuEzRC9RPW4C+DhXftgXwvsXDhQUd0JWmoueWmLIcFt3UisgOOr9DnHciA1yrE9 tQru9Zu7fT/AvQ7zG58B7iPKafdfoFVxWTsB+opIly5g2rDz9PTbULgvzrviCDzj4/CkvaCJ3Eir 2A4PDhiLHpyD/A1x8xaXQ/JsdifnQ/ze+OL4m9CxJxRoL4CYI+LNGBU8L2plHjfoL8iA/hqELlsF 4W0Q9bX6vdsBCRPF/oRaUBw75B5HMyQsUI2EcYhtZU7MGugtNk/dbwe73z4kN0L0CZke7YbRj6zV YzXwz9nR0VvLYEV03L8rl8B1j36q9SJMaBFRrpdAO2Ab2gNQ3CVybfS3MMXrqkyfBsph2a02AXX2 PO4DvfIWIcBvzweQbfKCXQu/TNNLW9PAVzxe6/NB++8jt9s6QZkrtyk5QE9kHYAS2RDZFCmHcZ/V O74Y+meFegOX4Lkapzb1PrjWYjjjYKzQzBkvhHC7NSncBU8qTNdQJvStNi48fAfGqqzvxtJhNGJO HTsKps9Ktx6Bps8xFj3JgsH1xuygA85/2b/1bBdMXCMcKQZk/u1uzUyCplf0vh+/AP1Xe7peDEPL ZdLgVdj1ru+r6hhwNyp/uL3wX6PRF6iB4KdGVrASNH9BKOzXwVpgLYy8Du95J22pOAPB49beoBfC Jfal8ElIb499I6MH5HzxvqwCx0bqHevAuVJsdh6FxAa1JakDAtmhmYFK8BeFmh/FgtDym7PBdDob I1tcqZrx1BQlLSUFkoJaadJGiKlVumN7wHVD2eTSgIWYzIJwtX0gvBqG6+yS4VIYfMs6HRwEf5P9 yeMGMPJVbyhoOYUj7aoK5yfLHXIAlsfJj6kBtdP+TW4DIA8vgDzGFQAkQQBRwioAmigHUGaKQwCi mlchMkMcFh64OPI/QLSjdm0wihoAAAAldEVYdGRhdGU6Y3JlYXRlADIwMTktMDgtMTBUMDM6NDU6 MTYtMDc6MDBV2/HBAAAAJXRFWHRkYXRlOm1vZGlmeQAyMDE5LTA4LTEwVDAzOjQ1OjE2LTA3OjAw JIZJfQAAABl0RVh0U29mdHdhcmUAQWRvYmUgSW1hZ2VSZWFkeXHJZTwAAAAASUVORK5CYII="/></svg>';
            function addGlobalStyle(css) {
                var head, style;
                head = document.getElementsByTagName('head')[0];
                if (!head) { return; }
                style = document.createElement('style');
                style.type = 'text/css';
                style.innerHTML = css;
                head.appendChild(style);
            }
            addGlobalStyle(`
#Ful{position:fixed;top:5em;left:0;padding:0;z-index:999999;}
#Ful svg{float:right;}
.F1{position:relative;padding-right:.5em;width:1.5em;opacity:0.8;cursor:pointer;}
.F1:hover{opacity:2;}
.F1 span{margin:0;padding:1em .3em;background-color:#00C8FF;color:white;display:block;}
.F2{position:absolute;top:0;left:1.5em;display:none;margin:0;padding:0;}
.F2 li{width:8.5em;margin:0;padding:.15em .5em;background:#00FFFF;cursor:pointer;}
.F2 li:hover{color:red!important;background:white;}
.F1:hover .F2{display:block;}
.F1 span, .F2, .F2 li{border-radius:.2em;}
`);

            var defaultapi = {
                title: "解析啦,失效请更换接口,鼠标停留出现多个接口",
                url: "https://api.jiexi.la/?url="
            };
            var apis =[
                {name:"解析啦"+IQiyiIcon+VQQIcon+YoukuIcon,url:"https://api.jiexi.la/?url=",title:"优酷超清、腾讯超清、爱奇艺高清"},
                {name:"QH解析"+IQiyiIcon+VQQIcon+YoukuIcon,url:"https://api.qianhaijishi.net/?url=",title:"优酷超清、腾讯超清、爱奇艺超清"},
                {name:"1717云"+IQiyiIcon+VQQIcon+YoukuIcon,url:"https://www.1717yun.com/jx/ty.php?url=",title:"优酷超清、腾讯超清、爱奇艺高清、芒果超清"},
                {name:"大亨解析"+IQiyiIcon+VQQIcon+YoukuIcon,url:"http://jx.13tv.top/?url=",title:"优酷超清、腾讯超清、爱奇艺超清"},
                {name:"17K云"+IQiyiIcon+VQQIcon+YoukuIcon,url:"http://17kyun.com/api.php?url=",title:"优酷超清、腾讯高清、爱奇艺高清、芒果超清"},
                {name:"乐多解析"+IQiyiIcon+VQQIcon+YoukuIcon,url:"https://api.leduotv.com/wp-api/ifr.php?vid=",title:"优酷超清、腾讯高清、爱奇艺高清、芒果超清"},
                {name:"19解析"+IQiyiIcon+VQQIcon+YoukuIcon,url:"http://19g.top/?url=",title:"优酷超清、腾讯高清、爱奇艺高清、芒果超清"},
                {name:"55解析"+IQiyiIcon+VQQIcon+YoukuIcon,url:"http://55jx.top/?url=",title:"优酷超清、腾讯高清、爱奇艺高清、芒果超清"},
                {name:"618解析"+IQiyiIcon+VQQIcon+YoukuIcon,url:"https://jx.618g.com/?url=",title:"优酷超清、腾讯高清、爱奇艺高清、芒果超清"},
                {name:"660解析"+IQiyiIcon+VQQIcon+YoukuIcon,url:"https://660e.com/?url=",title:"优酷超清、腾讯高清、爱奇艺高清"},
                {name:"CK解析"+IQiyiIcon+VQQIcon+YoukuIcon,url:"https://www.ckmov.vip/api.php?url=",title:"优酷超清、腾讯超清、爱奇艺高清"},
                {name:"OOP解析"+IQiyiIcon+VQQIcon+YoukuIcon,url:"http://api.13tv.top/jiexi/?url=",title:"优酷超清、腾讯超清、爱奇艺高清"},
                {name:"下视频"+IQiyiIcon+VQQIcon+YoukuIcon,url:"http://jiexi2.xiashipin.net/jiexi/?url=",title:"优酷超清、腾讯超清、爱奇艺高清"},
                {name:"花园解析"+IQiyiIcon+VQQIcon+YoukuIcon,url:"http://j.zz22x.com/jx/?url=",title:"优酷超清、腾讯超清、爱奇艺高清"},
                {name:"小蒋解析"+IQiyiIcon+VQQIcon,url:"https://www.kpezp.cn/jlexi.php?url=",title:"腾讯超清、爱奇艺高清、芒果超清"},
                {name:"无名解析"+IQiyiIcon+VQQIcon,url:"https://www.administratorw.com/admin.php?url=",title:"腾讯超清、爱奇艺高清、芒果超清"},
            ];
            var defaultapi2 = {
                title: "1717云,失效请更换接口,鼠标停留出现多个接口",
                url: "https://www.1717yun.com/jx/ty.php?url="
            };
            var apis2 =[
                {name:"OK解析"+IQiyiIcon+VQQIcon+YoukuIcon,url:"http://okjx.cc/?url=",title:"优酷超清、腾讯标清、爱奇艺超清、芒果超清"},
                {name:"K8解析"+IQiyiIcon+VQQIcon+YoukuIcon,url:"http://k8aa.com/jx/index.php?url=",title:"优酷超清、腾讯标清、爱奇艺超清、芒果超清"},
                {name:"F41解析"+IQiyiIcon+VQQIcon+YoukuIcon,url:"https://jx.f41.cc/?url=",title:"优酷超清、腾讯标清、爱奇艺超清、芒果超清"},
                {name:"哈哈解析"+IQiyiIcon+VQQIcon+YoukuIcon,url:"http://gege.ha123.club/gege1234/index.php?url=",title:"优酷超清、腾讯标清、爱奇艺超清、芒果超清"},
                {name:"明日解析"+IQiyiIcon+VQQIcon+YoukuIcon,url:"https://www.qianyicp.com/jiexi/index.php?url=",title:"优酷超清、腾讯标清、爱奇艺超清、芒果超清"},
                {name:"颜亦解析"+IQiyiIcon+VQQIcon+YoukuIcon,url:"https://jsap.attakids.com/?url=",title:"优酷超清、腾讯标清、爱奇艺超清、芒果超清"},
                {name:"BL解析"+IQiyiIcon+VQQIcon+YoukuIcon,url:"https://vip.bljiex.com/?v=",title:"优酷超清、腾讯标清、爱奇艺高清、芒果超清"},
                {name:"MW解析"+IQiyiIcon+VQQIcon+YoukuIcon,url:"http://jx.mw0.cc/?url=",title:"优酷超清、腾讯标清、爱奇艺高清、芒果超清"},
                {name:"维多解析"+IQiyiIcon+VQQIcon+YoukuIcon,url:"https://jx.ivito.cn/?url=",title:"优酷超清、腾讯标清、爱奇艺高清"},
                {name:"热点解析"+IQiyiIcon+VQQIcon+YoukuIcon,url:"http://jx.rdhk.net/?v=",title:"优酷超清、腾讯标清、爱奇艺标清"},
                {name:"TV920"+IQiyiIcon+VQQIcon+YoukuIcon,url:"https://api.tv920.com/vip/?url=",title:"优酷超清、腾讯标清、爱奇艺标清、芒果超清"},
                {name:"TN解析"+IQiyiIcon+VQQIcon,url:"http://www.33tn.cn/?url=",title:"腾讯标清、爱奇艺高清、芒果超清"},
            ];
            window.FEL = function(div){return document.createElement(div);};
            var div = FEL("div");
            var FT1 = '', i = 0;
            var FT2 = '',j = 0;

            for (i in apis) {
                FT1 += `<li data-order=${i} data-url="${apis[i].url}" title="${apis[i].title}" onclick="window.open(this.dataset.url+location.href)">${apis[i].name}</li>`;
            }
            for (j in apis2) {
                FT2 += `<li data-order=${j} data-url="${apis2[j].url}" title="${apis2[j].title}" onclick="window.open(this.dataset.url+location.href)">${apis2[j].name}</li>`;
            }
            div.innerHTML = `
<ul id="Ful">
<li class="F1"><span title="${defaultapi.title}" onclick="window.open(\'${defaultapi.url}\'+window.location.href)">▶</span><ul class="F2">${FT1}</ul></li>
<li class="F1"><span title="${defaultapi2.title}" onclick="window.open(\'${defaultapi2.url}\'+window.location.href)">①</span><ul class="F2">${FT2}</ul></li>
</ul>
`;
            document.body.appendChild(div);
        }
        $(cssSelector).append(obtainAppendHtml(host, coupon,pid,search, pname, Clabel, RedPacket, Rlabel, AllSearch,Dlabel,Elabel,DPacket,EPacket));
    });

    function obtainAppendHtml(host, coupon,pid,search, pname, Clabel, RedPacket, Rlabel, AllSearch,Dlabel,Elabel,DPacket,EPacket) {
        if (host.indexOf('taobao.com') > 0) {
            return '<div class="div-inline"><div class="tb-btn-buy" style="padding-top:11px;"><a href="' + coupon + pid + '" target="_blank">' + Clabel + '</a></div></div>'
                + '<div class="div-inline"><div class="tb-btn-add" style="padding-top:11px;"><a href="' + search + encodeURI(pname) + '" target="_blank">' + AllSearch + '</a></div></div>'
                +'<div class="div-inline"><div class="tb-btn-buy" style="padding-top:11px;"><a href="http://lctnq.yhzu.cn" target="_blank">备用查券地址</a></div></div>'
                + '<div class="div-inline"><div class="tb-btn-add" style="padding-top:11px;"><a href="' + RedPacket + '" target="_blank">' + Rlabel + '</a></div></div>'
                +'<div class="div-inline"><div class="tb-btn-buy" style="padding-top:11px;"><a href="' + DPacket + ' " title="每天可拆3次，5月29日20点-6.20" target="_blank">' + Dlabel + '</a></div></div>'
                +'<div class="div-inline"><div class="tb-btn-add" style="padding-top:11px;"><a href="' + EPacket + '"  title="每天可拆3次，5月30日12点-6.18" target="_blank">' + Elabel + '</a></div></div>'
        } else if (host == 'chaoshi.detail.tmall.com') {
            return '<br/><br/><br/><div class="div-inline"><div class="tb-btn-buy tb-btn-sku"  style="padding-top:11px;"><a href="' + coupon + pid + '" target="_blank">' + Clabel + '</a></div></div>'
                + '<div class="div-inline"><div class="tb-btn-basket tb-btn-sku " style="padding-top:11px;"><a href="' + search + encodeURI(pname) + '" target="_blank">' + AllSearch + '</a></div></div>'
                +'<div class="div-inline"><div class="tb-btn-buy tb-btn-sku"  style="padding-top:11px;"><a href="http://lctnq.yhzu.cn" target="_blank">备用查券地址</a></div></div>'
                + '<div class="div-inline"><div class="tb-btn-basket tb-btn-sku " style="padding-top:11px;"><a href="' + RedPacket + '" target="_blank">' + Rlabel + '</a></div></div>'
                +'<div class="div-inline"><div class="tb-btn-buy tb-btn-sku"  style="padding-top:11px;"><a href="' + DPacket + '" title="每天可拆3次，5月29日20点-6.20" target="_blank">' + Dlabel + '</a></div></div> '
                +'<div class="div-inline"><div class="tb-btn-basket tb-btn-sku " style="padding-top:11px;"><a href="' + EPacket + '" title="每天可拆3次，5月30日12点-6.18" target="_blank">' + Elabel + '</a></div></div>'
        } else if (host.indexOf('tmall.com') > 0 || host == 'detail.liangxinyao.com') {
            return '<div class="div-inline"><div class="tb-btn-buy tb-btn-sku"  style="padding-top:11px;"><a href="' + coupon + pid + '" target="_blank">' + Clabel + '</a></div></div>'
                + '<div class="div-inline"><div class="tb-btn-basket tb-btn-sku " style="padding-top:11px;"><a href="' + search + encodeURI(pname) + '" target="_blank">' + AllSearch + '</a></div></div>'
                +'<div class="div-inline"><div class="tb-btn-buy tb-btn-sku"  style="padding-top:11px;"><a href="http://lctnq.yhzu.cn" target="_blank">备用查券地址</a></div></div>'
                + '<div class="div-inline"><div class="tb-btn-basket tb-btn-sku " style="padding-top:11px;"><a href="' + RedPacket + '" target="_blank">' + Rlabel + '</a></div></div>'
                +'<div class="div-inline"><div class="tb-btn-buy tb-btn-sku"  style="padding-top:11px;"><a href="' + DPacket + '" title="每天可拆3次，5月29日20点-6.20" target="_blank">' + Dlabel + '</a></div></div> '
                +'<div class="div-inline"><div class="tb-btn-basket tb-btn-sku " style="padding-top:11px;"><a href="' + EPacket + '" title="每天可拆3次，5月30日12点-6.18" target="_blank">' + Elabel + '</a></div></div>'
        } else if (host.indexOf('jd.com') > 0) {
            return '<a href="' + coupon + pid + '" target="_blank" class="btn-special1 btn-lg">' + Clabel + '</a>'
                + '<br/><br/><br/><a href="' + search + encodeURI(pname) + '" target="_blank" class="btn-special1 btn-lg">' + AllSearch + '</a>'
                + '<a href="' + RedPacket + '" target="_blank" class="btn-special1 btn-lg">' + Rlabel + '</a>'
            //+'<a href="' + DPacket + '" title="每天可拆，可以领到11月11号" target="_blank" class="btn-special1 btn-lg">' + Dlabel + '</a>'
                +'<a href="' + EPacket + '" title="每天可拆3次，5月30日12点-6.18" target="_blank" class="btn-special1 btn-lg">' + Elabel + '</a>';
        } else if (host.indexOf('vip.com') > 0) {
            return '<div id="J-button-box" class="button-box" style="margin-left:40px";><div class="ui-btn-loading-before clearfix J_cartAdd_Price">'
                + '<div class="hasComparePrice clearfix"><div class="comparePrice"><a  class="comparePricess" href="' + coupon + pid + '"  target="_blank">' + Clabel + '</a></div>'
                + '<div class="finalPrice"><span class="finalPrice_price" ><a class="comparePricess" href="' + search + encodeURI(pname) + '" target="_blank">' + AllSearch + '</a></span></div>'
                + '<div class="hasComparePrice clearfix"><div class="comparePrice"><a  class="comparePricess" href="' + Rlabel + '" target="_blank">红包全品券</a></div>'
                + '<div class="finalPrice"><span class="finalPrice_price" ><a class="comparePricess" href="' + RedPacket + '" target="_blank">最新活动</a></span></div>'
                + '</div></div>'
        }
    }
})();